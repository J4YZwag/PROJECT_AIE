require "application_system_test_case"

class PostsTest < ApplicationSystemTestCase
  test "creating a post" do
    visit posts_url
    click_on "New Post"

    fill_in "Title", with: "My Test Post"
    fill_in "Content", with: "This is a test post."
    click_on "Create Post"

    assert_text "Post was successfully created"
    assert_text "My Test Post"
  end
end