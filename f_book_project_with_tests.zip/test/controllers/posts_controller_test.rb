require "test_helper"

class PostsControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get posts_url
    assert_response :success
  end

  test "should create post" do
    post posts_url, params: { post: { title: "Test Title", content: "Test Content" } }
    assert_response :redirect
    follow_redirect!
    assert_response :success
    assert_match "Test Title", response.body
  end
end