Rails.application.routes.draw do
  devise_for :users
  root "posts#index"

  resources :posts do
    resources :comments, only: [:index, :create, :destroy]
    member do
      post 'like'
      get 'like'
      get 'destroy'  
    end
  end
end
