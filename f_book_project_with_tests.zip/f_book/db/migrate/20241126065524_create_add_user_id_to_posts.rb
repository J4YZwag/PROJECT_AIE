class CreateAddUserIdToPosts < ActiveRecord::Migration[7.2]
  def change
    create_table :add_user_id_to_posts do |t|
      t.references :user, null: false, foreign_key: true

      t.timestamps
    end
  end
end
