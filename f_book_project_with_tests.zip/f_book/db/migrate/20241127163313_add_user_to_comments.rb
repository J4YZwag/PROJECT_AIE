class AddUserToComments < ActiveRecord::Migration[6.0]
  def change
    unless column_exists?(:comments, :user_id)
      add_reference :comments, :user, foreign_key: true
    end
  end
end
