class User < ApplicationRecord
    devise :database_authenticatable, :registerable, :recoverable, :rememberable, :validatable
    #has_secure_password
    has_many :posts
    has_many :comments
    has_many :likes
end