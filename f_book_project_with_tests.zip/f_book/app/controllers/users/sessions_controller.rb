class Users::SessionsController < Devise::SessionsController
    # Overriding the create action to add debug logging
    def create
      Rails.logger.debug "User email: #{params[:user][:email]}"
      Rails.logger.debug "User password: #{params[:user][:password]}"
      Rails.logger.debug "Params: #{params.inspect}"
      super  # Call Devise's default create action
    end
  end
  