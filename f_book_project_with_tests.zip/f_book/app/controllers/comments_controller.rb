class CommentsController < ApplicationController
  before_action :set_post
  before_action :set_comment, only: [:destroy]

  def index
    @comments = @post.comments
  end

  def create
    # ตรวจสอบว่า @post ถูกกำหนดค่าก่อนใช้งาน
    @comment = @post.comments.build(comment_params)
    @comment.user = current_user

    if @comment.save
      redirect_to post_comments_path(@post), notice: "Comment created successfully."
    else
      redirect_to post_comments_path(@post), alert: "Failed to create comment."
    end
  end

  def destroy
    @comment.destroy
    redirect_to post_path(@post), notice: "Comment deleted successfully!"
  end

  private

  def set_post
    @post = Post.find_by(id: params[:post_id])  # ตรวจสอบโพสต์จาก post_id
    redirect_to posts_path, alert: "Post not found." if @post.nil?
  end

  def set_comment
    @comment = @post.comments.find(params[:id])
  end

  def comment_params
    params.require(:comment).permit(:content)
  end
end
