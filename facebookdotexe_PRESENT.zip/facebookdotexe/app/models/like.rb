class Like < ApplicationRecord
  belongs_to :post
  belongs_to :user

  # Validate uniqueness to prevent duplicate likes
  validates :user_id, uniqueness: { scope: :post_id, message: "You can only like a post once" }
end
