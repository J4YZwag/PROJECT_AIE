class AddUserIdToPost < ApplicationRecord
  belongs_to :user
end
