class Post < ApplicationRecord
  has_many :likes, dependent: :destroy
  has_many :comments, dependent: :destroy
  before_destroy :check_dependencies
  belongs_to :user

  private

  def check_dependencies
    # ตรวจสอบว่ามีข้อมูลที่ต้องลบก่อน เช่น ความสัมพันธ์กับคอมเมนต์
    if comments.any?
      errors.add(:base, "Cannot delete post with comments")
      throw(:abort)
    end
  end
end
