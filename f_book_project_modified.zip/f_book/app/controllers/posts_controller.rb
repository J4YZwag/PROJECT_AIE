class PostsController < ApplicationController
  before_action :set_post, only: [:show, :edit, :update, :destroy, :like]
  before_action :authenticate_user!, only: [:new, :create, :edit, :update, :destroy]
  
    def index
      if params[:query].present?
        @posts = Post.where("title LIKE ?", "%#{params[:query]}%")
      else
        @posts = Post.all
      end
    end
  
    def show
      @comment = Comment.new
    end
  
    def new
      @post = Post.new
      resource = User.new  # หรือโมเดลที่เกี่ยวข้อง
      resource_name = :user
    end    
  
    def create
      @post = Post.new(post_params)
      @post.user_id = current_user.id  # ใช้ user_id แทนการตั้งค่า user
  
      if @post.save
        redirect_to posts_path, notice: "Post created successfully."
      else
        render :new, alert: "Failed to create post."
      end
    end
    
  
    def edit
       @post 
    end
    
  
    def update
      respond_to do |format|
        if @post.update(post_params)
          format.html { redirect_to @post, notice: "Post was successfully updated." }
          format.json { render :show, status: :ok, location: @post }
        else
          format.html { render :edit, status: :unprocessable_entity }
          format.json { render json: @post.errors, status: :unprocessable_entity }
        end
      end
    end
    
  
    def destroy
      @post = Post.find_by(id: params[:id])  # ใช้ find_by แทน find เพื่อป้องกันข้อผิดพลาดเมื่อไม่พบโพสต์
      if @post.nil?
        redirect_to posts_path, alert: "Post not found."
      else
        @post.destroy
        redirect_to posts_path, notice: "Post was successfully deleted."
      end
    end
        
     
       
  
    def like
      @post = Post.find(params[:id]) # ค้นหาโพสต์ตาม ID
      @post.likes.create(user: current_user) # เพิ่ม Like เชื่อมกับผู้ใช้ที่ล็อกอิน
      redirect_to posts_path, notice: "You liked a post!"
    end       
  
    private
  
    def set_post
      # ตรวจสอบว่า post_id มาจาก params[:id] หรือ params[:post_id] และว่าโพสต์มีอยู่ในฐานข้อมูล
      @post = Post.find_by(id: params[:id])  # ใช้ find_by เพื่อลดข้อผิดพลาดเมื่อไม่พบโพสต์
      if @post.nil?
        redirect_to posts_path, alert: "Post not found."
      end
    end
  
    def post_params
      params.require(:post).permit(:title, :content)
    end

    def comment_params
      params.require(:comment).permit(:content)
    end
  end
 