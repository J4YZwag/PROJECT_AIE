// Configure your import map in config/importmap.rb. Read more: https://github.com/rails/importmap-rails
import "@hotwired/turbo-rails"
import "controllers"
//= require rails-ujs
import Rails from "@rails/ujs"
Rails.start()
//= require rails-ujs
//= require_tree .
