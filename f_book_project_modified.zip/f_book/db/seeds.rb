# สร้างผู้ใช้
user = User.create(email: "user@example.com", password: "password", password_confirmation: "password")

# สร้างโพสต์ที่เชื่อมโยงกับผู้ใช้
Post.create(title: "Welcome to F-book", content: "This is the first post!", user_id: user.id)
Post.create(title: "Second Post", content: "Enjoy exploring this app.", user_id: user.id)

# สร้างโพสต์ตัวอย่างเพิ่มเติมพร้อมคอมเมนต์
5.times do |i|
  post = Post.create(title: "Post ##{i + 1}", content: "Content for post ##{i + 1}", user_id: user.id)
  3.times do |j|
    post.comments.create(content: "Comment ##{j + 1} for Post ##{i + 1}")
  end
end
