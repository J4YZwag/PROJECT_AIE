# frozen_string_literal: true

class AddDeviseToUsers < ActiveRecord::Migration[7.2]
  def self.up
    change_table :users do |t|
      # ตรวจสอบว่าไม่มีคอลัมน์ 'email' อยู่แล้วก่อน
      unless column_exists?(:users, :email)
        t.string :email, null: false, default: ""
      end

      # ตรวจสอบว่าไม่มีคอลัมน์ 'encrypted_password' อยู่แล้วก่อน
      unless column_exists?(:users, :encrypted_password)
        t.string :encrypted_password, null: false, default: ""
      end

      # สำหรับคอลัมน์อื่นๆ ที่เกี่ยวข้องกับ Devise
      unless column_exists?(:users, :reset_password_token)
        t.string :reset_password_token
      end
      unless column_exists?(:users, :reset_password_sent_at)
        t.datetime :reset_password_sent_at
      end
      unless column_exists?(:users, :remember_created_at)
        t.datetime :remember_created_at
      end
    end

    # เพิ่ม index สำหรับคอลัมน์ที่ต้องการ
    add_index :users, :email, unique: true unless index_exists?(:users, :email)
    add_index :users, :reset_password_token, unique: true unless index_exists?(:users, :reset_password_token)
  end

  def self.down
    # Rollback ให้ลบคอลัมน์ Devise หากต้องการ
    change_table :users do |t|
      t.remove :email, :encrypted_password, :reset_password_token, :reset_password_sent_at, :remember_created_at
    end
    remove_index :users, :email
    remove_index :users, :reset_password_token
  end

  def change
    # ใช้ 'add_column' ถ้าไม่มี column นี้
    unless column_exists?(:users, :password_digest)
      add_column :users, :password_digest, :string
    end
  end
end
